package com.example.pr26;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class TestActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.test_screen);
    }
    public void OnClick(View view){
        SQLiteDatabase db = getBaseContext().openOrCreateDatabase("app.db", MODE_PRIVATE, null);
        Cursor query = db.rawQuery("SELECT * FROM clients;", null);
        TextView textView = findViewById(R.id.testText);
        textView.setText("");
        while(query.moveToNext()){
            String name = query.getString(0);
            String phone = query.getString(1);
            textView.append("Имя: " + name + "Номер телефона: " + phone + "\n");
        }
        query.close();
        db.close();

    }
}
