package com.example.pr26;

import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;

import androidx.appcompat.app.AppCompatActivity;

import java.util.Locale;


public class SecondActivity extends AppCompatActivity{
    String[] text = { "Нежный бархатистый вкус ", "закрой"};
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.second_screen);


        Spinner spinner = findViewById(R.id.spinner);
        // Создаем адаптер ArrayAdapter с помощью массива строк и стандартной разметки элемета spinner
        ArrayAdapter<String> adapter = new ArrayAdapter(this, android.R.layout.simple_spinner_item, text);
        // Определяем разметку для использования при выборе элемента
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        // Применяем адаптер к элементу spinner
        spinner.setAdapter(adapter);
    }
    public void toMapa(View view){
        String uri = String.format(Locale.CANADA.CANADA, "geo:59.915494,30.409456", 59, 30);
        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(uri));
        startActivity(intent);
    }
    public void toNewActivity(View view){
        Intent intent = new Intent(this, ThirdActivity.class);
        startActivity(intent);
    }
    public void SendData(View view){
        SQLiteDatabase db = getBaseContext().openOrCreateDatabase("app.db",MODE_PRIVATE,null);
        db.execSQL("CREATE TABLE IF NOT EXISTS clients (nameUser TEXT, phone TEXT)");
        EditText editTextt = findViewById(R.id.tb_Name);
        String nameUser = editTextt.getText().toString();
        editTextt = findViewById(R.id.tb_Tel);
        String phone = editTextt.getText().toString();
        String exception = String.format("INSERT OR IGNORE INTO clients VALUES ('%s', '%s1')",nameUser,phone);
        db.execSQL(exception);
        db.close();
    }
    public void toTestActivity(View view){
        Intent intent = new Intent(this, TestActivity.class);
        startActivity(intent);
    }
}
